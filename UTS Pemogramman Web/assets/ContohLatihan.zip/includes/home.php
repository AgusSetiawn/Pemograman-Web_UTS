    <!-- Hero Section -->
    <section class="jumbotron text-center">
        <div class="container">
            <h1 class="display-4">Halo, Saya Muhammad Prayoga</h1>
            <p class="lead">Mahasiswa - Teknik Informatika</p>
            <a href="?page=about" class="btn btn-danger btn-lg">Lihat Portofolio</a>
        </div>
    </section>

    <!-- Tentang Saya -->
    <section id="tentang" class="container py-5">
        <div class="row">
            <div class="col-md-6">
                <img src="assets/images/profile.jpg" alt="Profile" class="img-fluid rounded">
            </div>
            <div class="col-md-6">
                <h2>Tentang Saya</h2>
                <p>Saya seorang Mahasiswa aktif di Universitas Pelita Bangsa jurusan Teknik Informatika,
                    saat ini sedang menempuh semester 3.</p>
            </div>
        </div>
    </section>
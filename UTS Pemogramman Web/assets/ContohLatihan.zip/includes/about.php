<!-- Portfolio Section -->
<section id="portfolio" class="container py-5">
    <h2 class="text-center mb-4">Proyek Saya</h2>
    <div class="row">

        <!-- Project 1 -->
        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="assets/images/bekasi.png" class="card-img-top" alt="Kota Bekasi">
                <div class="card-body">
                    <h5 class="card-title">Kota Bekasi</h5>
                    <p class="card-text">Sejarah Kota Bekasi</p>
                    <a href="https://github.com/MuhammadPrayoga/Kota-Bekasi" class="btn btn-danger">Lihat Detail</a>
                </div>
            </div>
        </div>

        <!-- Project 2 -->
        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="assets/images/mobile.png" class="card-img-top" alt="Expensio">
                <div class="card-body">
                    <h5 class="card-title">Expensio</h5>
                    <p class="card-text">Aplikasi untuk membantu mengelola keuangan secara lebih efektif dan efisien</p>
                    <a href="https://github.com/MuhammadPrayoga/Expensio" class="btn btn-danger">Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
</section>